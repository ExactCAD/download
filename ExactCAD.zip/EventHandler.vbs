Option Explicit 
Dim doc, app, docOpen
Dim eventkey

Set app = Application
Call Scripting.AddTypeLibrary("MGCPCB.Application")
Scripting.AttachEvents app, "app"

Scripting.DontExit = True ' Keep on running

Sub app_OnOpenDocument(Flags)
	Dim StrLog
	Select Case Flags
		Case epcbOnOpenDocOpen ' document open event (start of session)
			Set doc = app.ActiveDocument
			lic_master_doc	
			
		Case epcbOnOpenDocReload ' document reload event (i.e. after setup params or forward anno)
			docOpen = flags  
    End Select
End Sub

'=========================================================================
' Event Handlers for document
'=========================================================================

Function doc_OnSave()
	'msgbox "OnSave"
End Function
'
Sub doc_OnClosing() 
	docOpen = 0
End Sub 

Sub doc_OnPreForwardAnnotate()
	dim p1, p2
	dim filesys
	
	p1 = doc.Path & "LogFiles\KeyinNetList.txt"
	p2 = doc.Path & "Config\KeyinNetList_old.txt"
	
	set filesys=CreateObject("Scripting.FileSystemObject")
	If filesys.FileExists(p1) Then
		filesys.CopyFile p1, p2
		
	Else
		write_netlist(1)
	End If 
End Sub

Sub doc_OnPostForwardAnnotate(res)	'res in this function call is a boolean. It can't be nothing, and it's not the document object.  Confusing in the help files. 
	dim shell
	dim path
	
	write_netlist(2)
	
	Set shell = CreateObject( "WScript.Shell" )
	path = "\\kuiper-prd-t02\shared\user\layout_team_contractor_scratch\Cashman\scripts\FA_LOG_FILE_REBUILD\bin\x64\Debug\FA_LOG_FILE_REBUILD.exe"
	
	shell.run path
	
End Sub

Sub doc_OnClosed() 
	docOpen = 0
	Scripting.DontExit = False 
End Sub 

Sub write_netlist(mode)

	dim net, nets
	dim part, parts
	dim comp, comps
	dim pin, pins
	dim str, ref
	dim list
	dim filesys
	dim ofile
	dim p1, p2
	dim ary()
	
	Set list = CreateObject("System.Collections.ArrayList")
	list.add "%net" & vbcrlf
	
	set nets = doc.nets(0)
	for each net in nets
		str = "\" & net.name & "\    "
		set pins = net.pins
		for each pin in pins
			set comp = pin.component
			ref = comp.refdes
			str = str & "\" & ref & "\-\" & pin.name & "\ "
		next
		list.add str
	next
	
	list.add vbcrlf & vbcrlf & "%Part" & vbcrlf
	
	set parts = doc.parts
	for each part in parts
		str = "\" & part.name & "\    "
		set comps = part.components
		for each comp in comps
			str = str & "\" & comp.refdes & "\ " 
		next
		list.add str
	next
	
	str = join(list.toarray(), vbcrlf)
	
	set filesys=CreateObject("Scripting.FileSystemObject")
	p1 = doc.Path & "LogFiles\KeyinNetList.txt"
	p2 = doc.Path & "Config\KeyinNetList_old.txt"
	
	
	if mode = 1 then
		Set ofile = filesys.CreateTextFile(p2,True)
		ofile.Write str
		ofile.Close
	Else
		Set ofile = filesys.CreateTextFile(p1,True)
		ofile.Write str
		ofile.Close
	end if
End Sub



'---------------------------------------
' Begin Validate Server Function
'---------------------------------------
Sub lic_master_doc()
	Set doc = app.ActiveDocument
	
	If Not (ValidateServer(doc) = 1) Then Exit Sub
	
	' only attach doc events if not done already. 
	' Avoids duplicate events firing
	If Scripting.Globals(eventkey) = "" then
		Scripting.Globals(eventkey) = "fred"		
		Scripting.AttachEvents doc, "doc"
	End If
End Sub	

Private Function ValidateServer(doc)
    Dim key, licenseServer, licenseToken
    ' Ask Expedition’s document for the key
    key = doc.Validate(0)
    ' Get license server
    Set licenseServer = CreateObject("MGCPCBAutomationLicensing.ApplicatiON")
    ' Ask the license server for the license token
    licenseToken = licenseServer.GetToken(key)
    ' Release license server
    Set licenseServer = Nothing
    ' Turn off error messages.  Validate may fail if the token is incorrect
    On Error Resume Next
    Err.Clear
    ' Ask the document to validate the license token
    doc.Validate (licenseToken)
    If Err Then
        ValidateServer = 0
    Else
        ValidateServer = 1
    End If
	

End Function
'---------------------------------------
' End Validate Server Function
'---------------------------------------

