'Option Explicit


dim shell
dim path
dim sMenu
dim sButton
dim i


Scripting.AddTypeLibrary("MGCPCB.ExpeditionPCBApplication")
Set shell = CreateObject( "WScript.Shell" )
path = shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\symbol"



Scripting.DontExit = True
Set objRegEx = CreateObject("VBScript.RegExp")
objRegEx.Global = True
objRegEx.Pattern = "NSETemp" 'Symbol has NSETemp in iCDBDir name



i = 0
Sub Application_ActivateView()
	'For some reason this is performed multiple times as a default. That is why i counter is in use.
	If i < 1 Then
		CheckIfSymbolOrSchematic()
		i = i + 1
	End If
End Sub


Sub CheckIfSymbolOrSchematic()
	tkyiCDBDir = GetProjectData.iCDBDir
	Set colMatches = objRegEx.Execute(tkyiCDBDir)
	
	If colMatches.Count > 0 Then
		'MsgBox "This is the symbol editor " &vbCRLF & tkyiCDBDir
		'Put your symbol automation code in here
		
		Set sMenu = CommandBars("Sheet Menu Bar").Controls.Add(cmdControlPopup,,,-1)
		sMenu.Caption = "ExactCAD"

		'Design Info
		Set sButton = sMenu.Controls.Add
		sButton.Caption = "Design Info"
		sButton.OnAction = "run " & shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\design_info\design_info.vbs"

		'Create the auto-annotate
		Set sButton = sMenu.Controls.Add
		sButton.Caption = "Auto Annotate"
		sButton.OnAction = "run " & shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\auto_annotate\auto_annotate.vbs"
		
		
		
		
		
		
	Else
		'MsgBox "This is the schematic editor " &vbCRLF & tkyiCDBDir
		'Put your schematic automation code in here
	End If
End Sub

