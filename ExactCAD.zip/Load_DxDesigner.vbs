Option Explicit


dim shell
dim path
dim sMenu
dim sButton
dim menu
dim menu2sub1
dim button1
dim button2
dim button3


Scripting.AddTypeLibrary("MGCPCB.ExpeditionPCBApplication")
Set shell = CreateObject( "WScript.Shell" )
path = shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\sch"



Scripting.DontExit = True


Set sMenu = CommandBars("Sheet Menu Bar").Controls.Add(cmdControlPopup,,,-1)
sMenu.Caption = "ExactCAD"

'Design Info
Set sButton = sMenu.Controls.Add
sButton.Caption = "Design Info"
sButton.OnAction = "run " & shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\design_info\design_info.vbs"

'Create the auto-annotate
Set sButton = sMenu.Controls.Add
sButton.Caption = "Auto Annotate"
sButton.OnAction = "run " & shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin\auto_annotate\auto_annotate.vbs"


set shell = nothing