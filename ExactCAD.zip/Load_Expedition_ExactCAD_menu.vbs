Option Explicit

Dim shell
Dim path
Dim app
Dim gui
Dim menubar, exmenu, item
Dim ctrls

Scripting.AddTypeLibrary("MGCPCB.ExpeditionPCBApplication")
Set shell = CreateObject( "WScript.Shell" )
path = shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin"
scripting.globals("path") = path



Set app = Application	'make connection with the Xpedition application
Set gui = app.Gui		'make connection with the Xpedition document's gui (graphical user interface)
set menubar = gui.CommandBars("Document Menu Bar")	'make connection with the Xpedition gui's menu and toolbar system
set exmenu = menubar.Controls.Add(cmdControlPopup,,,-1)	'creates the ExactCAD menu in the last position to the right

exmenu.Caption = "ExactCAD"	'gives the ExactCAD menu its name

set ctrls = exmenu.controls

set item = ctrls.add
item.caption = "Add Ground Vias"
item.OnAction = "run " & path & "\add_ground_vias\add_ground_vias.vbs"

set item = ctrls.add
item.caption = "Add Layer Stackup"
item.OnAction = "run " & path & "\add_layer_stackup_pcb\add_layer_stackup_pcb.vbs"

set item = ctrls.add
item.caption = "Add Shield Walls"
item.OnAction = "run " & path & "\add_shield_walls\add_shield_walls.vbs"

set item = ctrls.add
item.caption = "Auto Annotate"
item.OnAction = "run " & path & "\auto_annotate\auto_annotate.vbs"

set item = ctrls.add
item.caption = "Active Layer Display"
item.OnAction = "run " & path & "\active_layer_display\active_layer_display.vbs"

set item = ctrls.add
item.caption = "Cleanup UserLayers"
item.OnAction = "run " & path & "\cleanup_userlayers\cleanup_userlayers.vbs"

set item = ctrls.add
item.caption = "Clear UserLayer"
item.OnAction = "run " & path & "\clear_user_layer\clear_user_layer.vbs"

set item = ctrls.add
item.caption = "Compare Assy to BOM"
item.OnAction = "run " & path & "\compare_assy_to_bom\compare_assy_to_bom.vbs"

set item = ctrls.add
item.caption = "Design Info"
item.OnAction = "run " & path & "\design_info\design_info.vbs"


set item = ctrls.add
item.caption = "Diff Pair Tuner"
item.OnAction = "run " & path & "\diff_pair_tuner\diff_pair_tuner.vbs"

set item = ctrls.add
item.caption = "Drawing Notes"
item.OnAction = "run " & path & "\drawing_notes\drawing_notes.vbs"

set item = ctrls.add
item.caption = "Groups"
item.OnAction = "run " & path & "\groups\groups.vbs"

set item = ctrls.add
item.caption = "Netline Optimizer"
item.OnAction = "run " & path & "\netline_optimizer\netline_optimizer.vbs"	

set item = ctrls.add
item.caption = "Place Components"
item.OnAction = "run " & path & "\place_components\place_components.vbs"

set item = ctrls.add
item.caption = "Place Designators"
item.OnAction = "run " & path & "\place_designators\place_designators.vbs"

set item = ctrls.add
item.caption = "Place Film Box"
item.OnAction = "run " & path & "\place_film_box\place_film_box.vbs"

'set item = ctrls.add
'item.caption = "Post Processor"
'item.OnAction = "run " & path & "\post_process\post_process.vbs"

set item = ctrls.add
item.caption = "Replace Vias"
item.OnAction = "run " & path & "\replace_vias\replace_vias.vbs"

set item = ctrls.add
item.caption = "Restore Ref Des"
item.OnAction = "run " & path & "\restore_ref_des\restore_ref_des.vbs"

set item = ctrls.add
item.caption = "RF / Power Pin Exit Configuration"
item.OnAction = "run " & path & "\rf_power_pin_exit\rf_power_pin_exit_configuration.vbs"

set item = ctrls.add
item.caption = "Shapester"
item.OnAction = "run " & path & "\shapester\shapester.vbs"

set item = ctrls.add
item.caption = "Short Vias"
item.OnAction = "run " & path & "\short_vias\short_vias.vbs"

set item = ctrls.add
item.caption = "Snap Vias"
item.OnAction = "run " & path & "\snap_vias\snap_vias.vbs"

set item = ctrls.add
item.caption = "Report Design Path"
item.OnAction = "run " & path & "\get_pcb_path\get_pcb_path.vbs"

set item = ctrls.add
item.caption = "Report Single Pin Nets"
item.OnAction = "run " & path & "\hotkeys\report_single_pin_nets.vbs"

set item = ctrls.add
item.caption = "Save PCB"
item.OnAction = "run " & path & "\bin\save_pcb\save_pcb.vbs"


'path = shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\EventHandler.vbs"
'shell.run chr(34) & path & chr(34)

set shell = nothing