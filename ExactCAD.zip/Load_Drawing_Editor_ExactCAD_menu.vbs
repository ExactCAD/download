Option Explicit

dim shell
dim path
Dim app, gui
dim menubar, exmenu, item
Dim ctrlsOption Explicit

Scripting.AddTypeLibrary("MGCPCB.DrawingEditorApplication")
Set shell = CreateObject( "WScript.Shell" )
path = shell.ExpandEnvironmentStrings("%EXACTCAD_PATH%") & "\bin"
scripting.globals("path") = path
set shell = nothing

Set app = Application	'make connection with the Drawing Editor application
Set gui = app.Gui		'make connection with the Drawing Editor document's gui (graphical user interface)
set menubar = gui.CommandBars("Document Menu Bar")	'make connection with the Drawing Editor gui's menu and toolbar system
set exmenu = menubar.Controls.Add(cmdControlPopup,,,-1)	'creates the ExactCAD menu in the last position to the right

exmenu.Caption = "ExactCAD"	'gives the ExactCAD menu its name

set ctrls = exmenu.controls

set item = ctrls.add
item.caption = "Drawing Notes"
item.OnAction = "run " & path & "\drawing_notes\drawing_notes.vbs"