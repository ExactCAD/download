Dim objFSO, sddhome, mginvoke, mglaunch
Dim output

Set objFSO = CreateObject("Scripting.FileSystemObject")

sddhome = get_sdd_home()

If sddhome = "" Then
	WScript.Quit 1
End If

get_wrappers

output = ""

If mginvoke <> "" Then
	'MsgBox "mginvoke: " & mginvoke
	output = "mginvoke" & vbTab & mginvoke & vbCrLf
Else
	MsgBox "mginvoke.exe does not appear to be in the standard location under SDD_HOME\common\win64\bin\:" & vbCrLf & _
			vbCrLf & "You will need to enter the path manually using the ExactCAD Licensing tool." & vbCrLf & _
			vbCrLf & "mginvoke has gone missing . . .", vbExclamation, "ExactCAD"
End If

If mglaunch <> "" Then
	'MsgBox "mglaunch: " & mglaunch
	output = output & "mglaunch" & vbTab & mglaunch & vbCrLf
Else
	MsgBox "mglaunch.exe does not appear to be in the standard location under SDD_HOME\common\win64\bin\:" & vbCrLf & _
			vbCrLf & "You will need to enter the path manually using the ExactCAD Licensing tool." & vbCrLf & _
			vbCrLf & "mglaunch has gone missing . . .", vbExclamation, "ExactCAD"	
End If

If output <> "" Then
	Dim objFile, strFilePath
	Dim objShell
	Dim exactcad_path
	
	Set objShell = CreateObject("WScript.Shell")
	exactcad_path = objShell.ExpandEnvironmentStrings("%EXACTCAD_PATH%")

	' Ensure %EXACTCAD_PATH% is defined and the directory exists before writing
	If exactcad_path = "%EXACTCAD_PATH%" Or Not objFSO.FolderExists(exactcad_path) Then
		MsgBox "EXACTCAD_PATH is not set or the folder does not exist:" & vbCrLf & _
				exactcad_path, vbCritical, "ExactCAD"
	Else
		' Handle paths with or without a trailing backslash
		strFilePath = objFSO.BuildPath(exactcad_path, "wrapper_paths.txt")

				' Parameters: FilePath, Overwrite (True/False), Unicode (True/False)
		Set objFile = objFSO.CreateTextFile(strFilePath, True, False)
		objFile.Write output
		objFile.Close

		' --- Read back and verify ---
		Dim strReadBack
		
		If objFSO.FileExists(strFilePath) Then
			' IOMode: 1 = ForReading
			Set objFile = objFSO.OpenTextFile(strFilePath, 1, False)
			If Not objFile.AtEndOfStream Then
				strReadBack = objFile.ReadAll
			Else
				strReadBack = ""
			End If
			objFile.Close

			If strReadBack = output Then
				MsgBox "Verification succeeded: " & exactcad_path & "\wrapper_paths.txt matches expected output.", vbInformation, "ExactCAD"
			Else
				MsgBox "Verification failed: file contents do not match expected output.", vbCritical, "ExactCAD"
				WScript.Quit 1
			End If
		Else
			MsgBox "Verification failed: wrapper_paths.txt was not found after writing.", vbCritical, "ExactCAD"
			WScript.Quit 1
		End If

		
	End If
End If


Sub get_wrappers()
	Dim path
	
	If sddhome <> "" Then
		path = objFSO.BuildPath(sddhome, "common\win64\bin\mginvoke.exe")

		If objFSO.FileExists(path) Then
			mginvoke = path
		Else
			mginvoke = ""
		End If
		
		path = objFSO.BuildPath(sddhome, "common\win64\bin\mglaunch.exe")

		If objFSO.FileExists(path) Then
			mglaunch = path
		Else
			mglaunch = ""
		End If
	Else
		mginvoke = ""
		mglaunch = ""
	End If
End Sub


' --- find the running Xpedition exe path via WMI ---
Function get_sdd_home()
	Dim objWMI, colProcs, objProc
	Dim path, idx, slashPos
	Const MARKER = "SDD_HOME"

	get_sdd_home = ""
	Set objWMI = GetObject("winmgmts:\\.\root\cimv2")
	Set colProcs = objWMI.ExecQuery( _
		"SELECT ExecutablePath FROM Win32_Process WHERE Name = 'ExpeditionPCB.exe'")
		
	If colProcs.Count = 0 Then
		MsgBox "Xpedition (ExpeditionPCB.exe) does not appear to be running." & vbCrLf & _
			   "Please start Xpedition before launching this tool.", _
			   vbExclamation, "ExactCAD"
		Exit Function
	End If

	For Each objProc In colProcs
		If Not IsNull(objProc.ExecutablePath) Then
			path = objProc.ExecutablePath

			idx = InStrRev(path, MARKER, -1, vbTextCompare)
			If idx > 0 Then
				slashPos = InStr(idx, path, "\")
				If slashPos > 0 Then
					get_sdd_home = Left(path, slashPos)
				End If
			End If

			Exit For
		End If
	Next
	
	If get_sdd_home = "" Then
		MsgBox "Found Xpedition, but could not locate SDD_HOME in its path:" & vbCrLf & _
			path & vbCrLf & "Contact ExactCAD support.", vbExclamation, "ExactCAD"
	End If
End Function
